
#include <stdio.h>

int main()
{
   int n;
   scanf("%d",&n);
   int arr[n],flag=1;
   for(int i=0;i<n;i++){
       scanf("%d",&arr[i]);
   }
   for(int i=0;i<n;i++){
       flag=1;
       for(int j=i+1;j<n;j++){
           if(arr[i]==arr[j] && flag!=0 && arr[i]!=-1){
               flag=0;
               printf("%d ",arr[i]);
               arr[j]=-1;
               
           }
       }
   }
    return 0;
}
