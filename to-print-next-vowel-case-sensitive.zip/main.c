/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<string.h>

int main()
{
    char s[100];
    scanf("%s",s);
    int i;
    for(i=0;i<s[i]!='\0';i++){
        if(s[i]!='a' && s[i]!='e' && s[i]!='i' && s[i]!='o' && s[i]!='u' && s[i]!='A' && s[i]!='E' && s[i]!='I' && s[i]!='O' && s[i]!='U'){
        
            printf("%c",s[i]);
        }
        else{
            if(s[i]=='a'){
            s[i]='e';
            printf("%c",s[i]);}
            else if(s[i]=='e'){
            s[i]='i';
            printf("%c",s[i]);}
            else if(s[i]=='i'){
            s[i]='o';
            printf("%c",s[i]);}
           else if(s[i]=='o'){
            s[i]='u';
            printf("%c",s[i]);}
           else if(s[i]=='u'){
            s[i]='a';
            printf("%c",s[i]);}
            
            else if(s[i]=='A'){
            s[i]='E';
            printf("%c",s[i]);}
            else if(s[i]=='E'){
            s[i]='I';
            printf("%c",s[i]);}
            else if(s[i]=='I'){
            s[i]='O';
            printf("%c",s[i]);}
            else if(s[i]=='O'){
            s[i]='U';
            printf("%c",s[i]);}
            else if(s[i]=='U'){
            s[i]='A';
            printf("%c",s[i]);}
        }

    }
    

    return 0;
}
