/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>

int main()
{
   int n,i;
   scanf("%d",&n);
   int arr[n];
   for(int i=0;i<n;i++){
       scanf("%d",arr+i);
   }
   int prev;
   if(n>1){
       prev=arr[0];
       arr[0]=arr[0]+arr[1]%10;
   }
   for( i=1;i<=n-2;i++){
       int newVal=arr[i]+prev%10+arr[i+1]%10;
       prev=arr[i];
       arr[i]=newVal;
   }
   if(n>1){
       arr[n-1]=arr[n-1]+prev%10;;
   }
   
   for(i=0;i<n;i++){
       printf("%d ",arr[i]);
   }
    return 0;
}
