/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String str = sc.nextLine();
        int n=str.length();
       // boolean result = str.matches("[a-zA-Z]+");
       // System.out.println("Original String : " + str);
        //System.out.println("Does string contain only Alphabets? : " + result);
        for(int i=0;i<n;i++){
            
        if(str.charAt(i)>='a' && str.charAt(i)<='z' || str.charAt(i)>='A' && str.charAt(i)<='Z'){
            System.out.print(str.charAt(i));
        }
        }
    }
}

